import CryptoJS from 'crypto-js';

// Key used for decryption - in a real application, this could be retrieved securely
// For development, we're using a static key, but this should be handled more securely
let encryptionKey = null;

/**
 * Set the encryption key for decrypting personal data
 * @param {string} key - The encryption key to use for decryption
 */
export const setEncryptionKey = (key) => {
  encryptionKey = key;
};

/**
 * Loads personal data from an encrypted file
 * @returns {Promise<Object>} - A promise that resolves to the decrypted personal data
 * @throws {Error} - If decryption fails or no key is set
 */
export const loadPersonalData = async () => {
  try {
    // If no key is set, use default data
    if (!encryptionKey) {
      console.warn("No encryption key provided. Using default data.");
      return null;
    }

    // Fetch the encrypted data file from the public directory
    const response = await fetch('/data/encrypted_personal_data.json');
    if (!response.ok) {
      throw new Error(`Failed to fetch encrypted data: ${response.statusText}`);
    }

    const { iv, encryptedData, salt } = await response.json();

    // Derive the key using PBKDF2
    const key = CryptoJS.PBKDF2(encryptionKey, CryptoJS.enc.Hex.parse(salt), {
      keySize: 256 / 32,
      iterations: 1000
    });

    // Decrypt the data
    const decryptedBytes = CryptoJS.AES.decrypt(
      encryptedData,
      key,
      {
        iv: CryptoJS.enc.Hex.parse(iv),
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7
      }
    );

    // Convert decrypted data to string and parse as JSON
    const decryptedText = decryptedBytes.toString(CryptoJS.enc.Utf8);
    return JSON.parse(decryptedText);
  } catch (error) {
    console.error("Error loading personal data:", error);
    throw new Error("Failed to decrypt personal data. Please check your encryption key.");
  }
};

/**
 * Creates a sample encrypted data file for testing purposes
 * @param {Object} data - The personal data to encrypt
 * @param {string} key - The encryption key
 * @returns {Object} - The encrypted data object containing iv, salt, and encryptedData
 */
export const createEncryptedData = (data, key) => {
  // Generate a random salt and initialization vector
  const salt = CryptoJS.lib.WordArray.random(128 / 8).toString(CryptoJS.enc.Hex);
  const iv = CryptoJS.lib.WordArray.random(128 / 8).toString(CryptoJS.enc.Hex);

  // Derive the key using PBKDF2
  const derivedKey = CryptoJS.PBKDF2(key, CryptoJS.enc.Hex.parse(salt), {
    keySize: 256 / 32,
    iterations: 1000
  });

  // Encrypt the data
  const encryptedData = CryptoJS.AES.encrypt(
    JSON.stringify(data),
    derivedKey,
    {
      iv: CryptoJS.enc.Hex.parse(iv),
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7
    }
  ).toString();

  // Return the encrypted data with iv and salt
  return { iv, salt, encryptedData };
};