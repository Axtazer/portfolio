import { createEncryptedData } from './dataLoader';
import CryptoJS from 'crypto-js';

/**
 * Sample personal data to encrypt
 * Replace this with your actual data in production
 */
const samplePersonalData = {
  name: "John Doe",
  email: "john.doe@example.com",
  phone: "+1 (555) 123-4567",
  location: "New York, USA",
  socialLinks: {
    linkedin: "https://linkedin.com/in/johndoe",
    github: "https://github.com/johndoe",
    twitter: "https://twitter.com/johndoe"
  },
  career: {
    currentTitle: "Senior Frontend Developer",
    yearsOfExperience: 8
  }
};

/**
 * This function demonstrates how to encrypt your personal data
 * and save it to a file that can be safely committed to a public repository
 */
export const encryptAndSavePersonalData = () => {
  // You would normally get this from a secure source or user input
  const encryptionKey = "your-secure-password";

  // Encrypt the data
  const encryptedData = createEncryptedData(samplePersonalData, encryptionKey);
  
  // In a real application, you would save this to a file
  // For this demo, we're just logging it to the console
  console.log("Encrypted Data:", encryptedData);
  
  // To save the file in a browser environment (for demonstration)
  const jsonString = JSON.stringify(encryptedData, null, 2);
  const blob = new Blob([jsonString], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  
  // Create a download link
  const a = document.createElement('a');
  a.href = url;
  a.download = 'encrypted_personal_data.json';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  
  return encryptedData;
};

/**
 * Helper function to generate a tool that can encrypt your data on the server-side
 * You can run this with Node.js before deploying your website
 * Example usage: node encryptData.js
 */
const encryptDataForProduction = () => {
  // Only run this code if we're in a Node.js environment
  if (typeof window === 'undefined') {
    const fs = require('fs');
    const path = require('path');
    
    // Get encryption key from command line or environment variable
    const encryptionKey = process.env.ENCRYPTION_KEY || "your-secure-password";
    
    // Encrypt the data
    const encryptedData = createEncryptedData(samplePersonalData, encryptionKey);
    
    // Save to the public/data directory
    const outputPath = path.join(__dirname, '../../public/data/encrypted_personal_data.json');
    
    // Ensure directory exists
    const dirPath = path.dirname(outputPath);
    if (!fs.existsSync(dirPath)) {
      fs.mkdirSync(dirPath, { recursive: true });
    }
    
    // Write the file
    fs.writeFileSync(outputPath, JSON.stringify(encryptedData, null, 2));
    console.log(`Encrypted data saved to ${outputPath}`);
    console.log("Keep your encryption key safe! You'll need it to decrypt the data in your website.");
  }
};

// Automatically run in Node.js environment
if (typeof window === 'undefined') {
  encryptDataForProduction();
}