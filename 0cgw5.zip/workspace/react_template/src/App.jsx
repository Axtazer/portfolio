import { lazy, Suspense } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import Experience from './components/Experience';
import Skills from './components/Skills';
import Projects from './components/Projects';
import Contact from './components/Contact';
import Footer from './components/Footer';

// Lazy load the 3D scene to improve initial page load
const Scene = lazy(() => import('./components/3d/Scene'));

function App() {
  return (
    <div className="bg-gray-900 text-white min-h-screen">
      <Navbar />
      
      <main>
        {/* Hero section with 3D model */}
        <section id="hero" className="relative h-screen">
          <Hero />
          <div className="absolute top-0 right-0 w-full h-full pointer-events-none">
            <Suspense fallback={<div className="w-full h-full flex items-center justify-center">Chargement...</div>}>
              <Scene />
            </Suspense>
          </div>
        </section>
        
        {/* Main content sections */}
        <section id="about" className="py-20">
          <About />
        </section>
        
        <section id="skills" className="py-20 bg-gray-800">
          <Skills />
        </section>
        
        <section id="experience" className="py-20">
          <Experience />
        </section>
        
        <section id="projects" className="py-20 bg-gray-800">
          <Projects />
        </section>
        
        <section id="contact" className="py-20">
          <Contact />
        </section>
      </main>
      
      <Footer />
    </div>
  );
}

export default App;