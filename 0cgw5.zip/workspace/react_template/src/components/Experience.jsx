import { useEffect, useRef } from 'react';
import { motion, useInView, useAnimation } from 'framer-motion';

function Experience() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.1 });
  const controls = useAnimation();
  
  useEffect(() => {
    if (isInView) {
      controls.start('visible');
    }
  }, [isInView, controls]);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3,
      }
    }
  };

  const itemVariants = {
    hidden: { y: 30, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { duration: 0.6 } }
  };

  const experiences = [
    {
      title: "Lead Developer",
      company: "TechInnovate",
      period: "2020 - Présent",
      description: "Dirigé une équipe de 5 développeurs dans la création d'applications web modernes. Amélioré l'efficacité du workflow de 35% grâce à l'implémentation de nouvelles méthodologies."
    },
    {
      title: "Développeur Full-Stack",
      company: "WebSolutions",
      period: "2018 - 2020",
      description: "Développé et maintenu plusieurs applications client avec React et Node.js. Collaboré étroitement avec les designers pour implémenter des interfaces utilisateur réactives."
    },
    {
      title: "Développeur Front-End",
      company: "DigitalCraft",
      period: "2016 - 2018",
      description: "Créé des interfaces web responsive et des animations interactives. Optimisé les performances et l'accessibilité des sites clients."
    },
    {
      title: "Stage en développement",
      company: "StartupLab",
      period: "2015 - 2016",
      description: "Participé au développement d'une application mobile de e-commerce. Implémenté des fonctionnalités utilisateur et corrigé des bugs."
    }
  ];

  return (
    <div className="container mx-auto px-4">
      <motion.div
        ref={ref}
        initial="hidden"
        animate={controls}
        variants={containerVariants}
        className="max-w-4xl mx-auto"
      >
        <motion.h2 
          className="text-3xl md:text-4xl font-bold mb-12 text-center"
          variants={itemVariants}
        >
          <span className="bg-gradient-to-r from-purple-500 to-blue-500 bg-clip-text text-transparent">Mon Parcours</span>
        </motion.h2>
        
        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-0 md:left-1/2 transform md:-translate-x-1/2 w-1 h-full bg-gradient-to-b from-purple-500 to-blue-600"></div>
          
          {/* Experience items */}
          <div className="space-y-12">
            {experiences.map((exp, index) => (
              <motion.div 
                key={index}
                variants={itemVariants}
                className={`flex flex-col md:flex-row ${index % 2 === 0 ? 'md:flex-row-reverse' : ''}`}
              >
                <div className="md:w-1/2"></div>
                <div className="relative flex md:w-1/2">
                  {/* Timeline dot */}
                  <div className="absolute top-0 left-0 md:left-auto md:right-auto md:-left-3 md:-translate-x-1/2 transform w-6 h-6 rounded-full bg-gradient-to-r from-purple-500 to-blue-600 border-4 border-gray-900 z-10"></div>
                  
                  <motion.div 
                    className="ml-10 md:ml-0 bg-gray-800 p-6 rounded-xl border border-gray-700 w-full md:mx-6"
                    whileHover={{ y: -5 }}
                    transition={{ type: "spring", stiffness: 300, damping: 10 }}
                  >
                    <h3 className="text-xl font-bold mb-1">{exp.title}</h3>
                    <h4 className="text-purple-400 font-medium mb-2">{exp.company}</h4>
                    <span className="inline-block bg-gray-700 px-3 py-1 text-sm rounded-full mb-3">{exp.period}</span>
                    <p className="text-gray-300">{exp.description}</p>
                  </motion.div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </motion.div>
    </div>
  );
}

export default Experience;