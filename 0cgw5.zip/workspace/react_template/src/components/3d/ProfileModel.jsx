import React, { useEffect, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { useGLTF, MeshDistortMaterial } from '@react-three/drei';

function ProfileModel({ position }) {
  const ref = useRef();
  
  // Since we don't have an actual 3D model file, we'll create a custom shape
  // that represents the user in an abstract way
  useFrame((state) => {
    const time = state.clock.getElapsedTime();
    ref.current.rotation.y = Math.sin(time / 4) / 8;
    ref.current.rotation.z = Math.sin(time / 4) / 8;
    ref.current.position.y = Math.sin(time / 1.5) / 10;
  });

  // Create a floating, animated 3D object representing a profile
  return (
    <group position={position}>
      {/* Main head shape */}
      <mesh ref={ref} castShadow receiveShadow>
        <sphereGeometry args={[1, 32, 32]} />
        <MeshDistortMaterial
          color="#8b5cf6"
          envMapIntensity={0.4}
          clearcoat={0.8}
          clearcoatRoughness={0}
          metalness={0.2}
          distort={0.4}
          speed={1.5}
        />
      </mesh>
      
      {/* Orbital rings */}
      <mesh rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[1.8, 0.05, 16, 100]} />
        <meshStandardMaterial color="#3b82f6" emissive="#3b82f6" emissiveIntensity={0.5} transparent opacity={0.6} />
      </mesh>
      
      <mesh rotation={[Math.PI / 4, Math.PI / 4, 0]}>
        <torusGeometry args={[1.6, 0.04, 16, 100]} />
        <meshStandardMaterial color="#8b5cf6" emissive="#8b5cf6" emissiveIntensity={0.5} transparent opacity={0.6} />
      </mesh>
      
      {/* Floating particles */}
      {[...Array(5)].map((_, i) => (
        <mesh key={i} position={[
          Math.sin(i * Math.PI * 2 / 5) * 1.5, 
          Math.cos(i * Math.PI * 2 / 5) * 1.5,
          0
        ]}>
          <sphereGeometry args={[0.1, 16, 16]} />
          <meshStandardMaterial color="#60a5fa" emissive="#60a5fa" emissiveIntensity={1} />
        </mesh>
      ))}
    </group>
  );
}

export default ProfileModel;