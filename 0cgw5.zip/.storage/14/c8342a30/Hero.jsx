import { motion } from 'framer-motion';

function Hero() {
  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { 
        staggerChildren: 0.2,
        delayChildren: 0.3,
      }
    }
  };
  
  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { duration: 0.5 } }
  };

  return (
    <div className="container mx-auto px-4 h-full flex items-center">
      <motion.div 
        className="max-w-2xl"
        initial="hidden"
        animate="visible"
        variants={containerVariants}
      >
        <motion.h2 
          className="text-purple-400 font-medium mb-2 text-xl"
          variants={itemVariants}
        >
          Bonjour, je suis
        </motion.h2>
        <motion.h1 
          className="text-5xl sm:text-6xl md:text-7xl font-bold mb-4 bg-gradient-to-r from-purple-500 to-blue-500 bg-clip-text text-transparent"
          variants={itemVariants}
        >
          Votre Nom
        </motion.h1>
        <motion.p 
          className="text-gray-400 text-xl mb-8"
          variants={itemVariants}
        >
          Développeur Full-Stack & Designer
        </motion.p>
        <motion.div 
          className="flex flex-wrap gap-4"
          variants={itemVariants}
        >
          <motion.div 
            className="bg-gray-800 bg-opacity-50 backdrop-blur-lg rounded-lg p-4 border border-gray-700"
            whileHover={{ scale: 1.05 }}
            transition={{ type: "spring", stiffness: 400, damping: 10 }}
          >
            <p className="text-gray-400 mb-1">Email</p>
            <p className="font-medium">votre.email@exemple.com</p>
          </motion.div>
          
          <motion.div 
            className="bg-gray-800 bg-opacity-50 backdrop-blur-lg rounded-lg p-4 border border-gray-700"
            whileHover={{ scale: 1.05 }}
            transition={{ type: "spring", stiffness: 400, damping: 10 }}
          >
            <p className="text-gray-400 mb-1">Téléphone</p>
            <p className="font-medium">+33 6 12 34 56 78</p>
          </motion.div>
          
          <motion.div 
            className="bg-gray-800 bg-opacity-50 backdrop-blur-lg rounded-lg p-4 border border-gray-700"
            whileHover={{ scale: 1.05 }}
            transition={{ type: "spring", stiffness: 400, damping: 10 }}
          >
            <p className="text-gray-400 mb-1">Localisation</p>
            <p className="font-medium">Paris, France</p>
          </motion.div>
        </motion.div>
      </motion.div>
    </div>
  );
}

export default Hero;
