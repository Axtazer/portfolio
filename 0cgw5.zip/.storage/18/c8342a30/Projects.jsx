import { useEffect, useRef } from 'react';
import { motion, useInView, useAnimation } from 'framer-motion';

function Projects() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.1 });
  const controls = useAnimation();
  
  useEffect(() => {
    if (isInView) {
      controls.start('visible');
    }
  }, [isInView, controls]);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3,
      }
    }
  };

  const itemVariants = {
    hidden: { y: 30, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { duration: 0.6 } }
  };

  const projects = [
    {
      title: "Application 3D Interactive",
      description: "Une application web permettant aux utilisateurs de visualiser et d'interagir avec des modèles 3D de produits.",
      technologies: ["Three.js", "React", "WebGL", "Node.js"],
      color: "from-purple-600 to-blue-600"
    },
    {
      title: "Plateforme E-learning",
      description: "Une plateforme complète avec cours vidéo, quiz interactifs et suivi de progression pour les apprenants.",
      technologies: ["Vue.js", "Express", "MongoDB", "AWS"],
      color: "from-blue-600 to-cyan-600"
    },
    {
      title: "Dashboard Analytics",
      description: "Interface de visualisation de données avec graphiques interactifs et rapports personnalisables.",
      technologies: ["React", "D3.js", "Firebase", "Material UI"],
      color: "from-purple-600 to-pink-600"
    },
    {
      title: "Application Mobile Fitness",
      description: "Application de suivi d'entraînement avec plans personnalisés et statistiques de progression.",
      technologies: ["React Native", "Redux", "Node.js", "GraphQL"],
      color: "from-green-600 to-blue-600"
    }
  ];

  return (
    <div className="container mx-auto px-4">
      <motion.div
        ref={ref}
        initial="hidden"
        animate={controls}
        variants={containerVariants}
        className="max-w-6xl mx-auto"
      >
        <motion.h2 
          className="text-3xl md:text-4xl font-bold mb-12 text-center"
          variants={itemVariants}
        >
          <span className="bg-gradient-to-r from-purple-500 to-blue-500 bg-clip-text text-transparent">Mes Projets</span>
        </motion.h2>
        
        <div className="grid md:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <motion.div 
              key={index}
              variants={itemVariants}
              whileHover={{ y: -10 }}
              transition={{ type: "spring", stiffness: 300, damping: 10 }}
              className="bg-gray-900 rounded-xl overflow-hidden border border-gray-800"
            >
              {/* Project image placeholder */}
              <div className={`h-48 bg-gradient-to-r ${project.color}`}>
                <div className="w-full h-full flex items-center justify-center text-white text-3xl font-bold opacity-30">
                  Projet {index + 1}
                </div>
              </div>
              
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">{project.title}</h3>
                <p className="text-gray-400 mb-4">{project.description}</p>
                
                <div className="flex flex-wrap gap-2 mb-4">
                  {project.technologies.map((tech, techIndex) => (
                    <span 
                      key={techIndex} 
                      className="px-3 py-1 text-xs font-medium bg-gray-800 rounded-full text-gray-300"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
                
                <div className="flex space-x-3">
                  <a 
                    href="#" 
                    className="px-4 py-2 text-sm font-medium text-white bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg hover:from-purple-700 hover:to-blue-700 transition-colors"
                  >
                    Voir le projet
                  </a>
                  <a 
                    href="#" 
                    className="px-4 py-2 text-sm font-medium text-white bg-gray-800 rounded-lg hover:bg-gray-700 transition-colors"
                  >
                    Code source
                  </a>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}

export default Projects;
