import { useEffect, useRef } from 'react';
import { motion, useInView, useAnimation } from 'framer-motion';

function About() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.2 });
  const controls = useAnimation();
  
  useEffect(() => {
    if (isInView) {
      controls.start('visible');
    }
  }, [isInView, controls]);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3,
      }
    }
  };

  const itemVariants = {
    hidden: { y: 30, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { duration: 0.6 } }
  };

  return (
    <div className="container mx-auto px-4">
      <motion.div
        ref={ref}
        initial="hidden"
        animate={controls}
        variants={containerVariants}
        className="max-w-4xl mx-auto"
      >
        <motion.h2 
          className="text-3xl md:text-4xl font-bold mb-12 text-center"
          variants={itemVariants}
        >
          <span className="bg-gradient-to-r from-purple-500 to-blue-500 bg-clip-text text-transparent">À propos de moi</span>
        </motion.h2>
        
        <div className="grid md:grid-cols-2 gap-8 items-center">
          <motion.div variants={itemVariants}>
            <div className="aspect-square relative bg-gradient-to-tr from-purple-700 to-blue-700 rounded-2xl overflow-hidden">
              {/* Placeholder for profile image */}
              <div className="absolute inset-0 flex items-center justify-center text-6xl font-bold text-gray-800">
                VP
              </div>
            </div>
          </motion.div>
          
          <motion.div variants={itemVariants} className="space-y-4">
            <p className="text-gray-300">
              Je suis un développeur passionné avec plus de 5 ans d'expérience dans la création d'applications web et mobiles innovantes. Mon approche combine créativité technique et sensibilité design pour créer des expériences utilisateur exceptionnelles.
            </p>
            
            <p className="text-gray-300">
              Ma spécialité réside dans le développement full-stack avec une expertise particulière en React, Node.js, et les technologies 3D pour le web. J'aime relever des défis complexes et trouver des solutions élégantes.
            </p>
            
            <p className="text-gray-300">
              En dehors du code, je m'intéresse à la photographie, aux voyages et à l'apprentissage continu de nouvelles technologies.
            </p>
            
            <motion.div
              className="inline-flex mt-4"
              whileHover={{ scale: 1.05 }}
              transition={{ type: "spring", stiffness: 400, damping: 10 }}
            >
              <a 
                href="#" 
                target="_blank" 
                rel="noopener noreferrer"
                className="px-6 py-3 bg-gradient-to-r from-purple-600 to-blue-600 text-white font-medium rounded-lg hover:from-purple-700 hover:to-blue-700 transition-colors"
              >
                Télécharger mon CV
              </a>
            </motion.div>
          </motion.div>
        </div>
      </motion.div>
    </div>
  );
}

export default About;
