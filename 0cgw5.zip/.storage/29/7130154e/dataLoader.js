/**
 * Utility for securely loading personal data from an encrypted file
 * without storing decrypted content in the repository
 */

// Import a lightweight encryption library - CryptoJS
import CryptoJS from 'crypto-js';

// URL of the encrypted data file on CDN
// This would be replaced with the actual CDN URL where the encrypted file is hosted
const ENCRYPTED_DATA_URL = 'https://your-cdn.com/encrypted-data.json'; 

// Default data to use if decryption fails or before data is loaded
const defaultData = {
  name: "Votre Nom",
  title: "Développeur Full-Stack & Designer",
  email: "votre.email@exemple.com",
  phone: "+33 6 12 34 56 78",
  location: "Paris, France"
};

/**
 * Fetches and decrypts personal data from a CDN-hosted encrypted file
 * @param {string} decryptionKey - Key used to decrypt the data
 * @returns {Promise<Object>} - Decrypted personal data
 */
export const loadPersonalData = async (decryptionKey = null) => {
  // If no decryption key is provided, return default data
  if (!decryptionKey) {
    console.log("No decryption key provided, using default data");
    return defaultData;
  }
  
  try {
    // Fetch the encrypted data
    const response = await fetch(ENCRYPTED_DATA_URL);
    if (!response.ok) {
      throw new Error(`Failed to fetch encrypted data: ${response.status}`);
    }
    
    // Get the encrypted text
    const encryptedData = await response.text();
    
    // Decrypt the data
    const bytes = CryptoJS.AES.decrypt(encryptedData, decryptionKey);
    const decryptedData = JSON.parse(bytes.toString(CryptoJS.enc.Utf8));
    
    console.log("Personal data loaded successfully");
    
    // Merge with default data to ensure all fields exist even if not in encrypted file
    return { ...defaultData, ...decryptedData };
  } catch (error) {
    console.error("Error loading personal data:", error);
    return defaultData;
  }
};

/**
 * Function to detect if a decryption key is available in the URL parameters
 * This allows for a workflow where the key is not stored in the repo
 * @returns {string|null} - The decryption key if found, null otherwise
 */
export const getDecryptionKeyFromUrl = () => {
  // Check if running in browser environment
  if (typeof window !== 'undefined') {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('key');
  }
  return null;
};

/**
 * Encryption utility - can be used locally before uploading to CDN
 * This function would be run locally, NOT in the production application
 * @param {Object} data - Data to encrypt
 * @param {string} encryptionKey - Key to use for encryption
 * @returns {string} - Encrypted data string
 */
export const encryptData = (data, encryptionKey) => {
  const jsonString = JSON.stringify(data);
  const encrypted = CryptoJS.AES.encrypt(jsonString, encryptionKey).toString();
  return encrypted;
};

/**
 * Initialize personal data loading when the application starts
 * @returns {Promise<Object>} - Personal data
 */
export const initPersonalData = async () => {
  const key = getDecryptionKeyFromUrl();
  return await loadPersonalData(key);
};
